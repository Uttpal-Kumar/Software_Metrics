(function () {
  const codeInput = document.getElementById("code-input");
  const btnAnalyze = document.getElementById("btn-analyze");
  const btnSample = document.getElementById("btn-sample");
  const errorBox = document.getElementById("error-box");
  const results = document.getElementById("results");
  const stats = window.JM1_STATS;
  const labels = window.FEATURE_LABELS || {};

  function fmt(n) {
    if (n === undefined || n === null) return "—";
    if (Math.abs(n) >= 100) return Math.round(n).toLocaleString();
    return (Math.round(n * 100) / 100).toLocaleString();
  }

  function setBadge(el, text, band) {
    el.textContent = text;
    el.className = "badge " + band;
  }

  async function analyze() {
    const code = codeInput.value;
    errorBox.classList.add("hidden");
    results.classList.add("hidden");
    btnAnalyze.disabled = true;
    btnAnalyze.textContent = "Analyzing…";

    try {
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code }),
      });
      const data = await res.json();

      if (!res.ok) {
        errorBox.textContent = data.error || "Something went wrong.";
        errorBox.classList.remove("hidden");
        return;
      }

      render(data);
      results.classList.remove("hidden");
    } catch (err) {
      errorBox.textContent = "Could not reach the analyzer. Try again.";
      errorBox.classList.remove("hidden");
    } finally {
      btnAnalyze.disabled = false;
      btnAnalyze.textContent = "Analyze";
    }
  }

  function render(data) {
    document.getElementById("mi-value").textContent = data.maintainability_index;
    setBadge(document.getElementById("mi-badge"), data.maintainability_label, data.maintainability_band);

    document.getElementById("risk-value").textContent = Math.round(data.defect_probability * 100) + "%";
    setBadge(document.getElementById("risk-badge"), data.risk_label, data.risk_band);

    const tbody = document.getElementById("metrics-table-body");
    tbody.innerHTML = "";
    Object.keys(data.features).forEach((key) => {
      const tr = document.createElement("tr");
      const clean = stats ? stats.mean_clean[key] : null;
      const defective = stats ? stats.mean_defective[key] : null;
      tr.innerHTML =
        "<td>" + (labels[key] || key) + "</td>" +
        "<td class='num'>" + fmt(data.features[key]) + "</td>" +
        "<td class='num'>" + fmt(clean) + "</td>" +
        "<td class='num'>" + fmt(defective) + "</td>";
      tbody.appendChild(tr);
    });

    const approxNote = document.getElementById("approx-note");
    if (data.approximated && data.approximated.length) {
      const names = data.approximated.map(k => labels[k] || k).join(", ");
      approxNote.textContent = "Approximated (not derived from full control-flow analysis): " + names + ".";
    } else {
      approxNote.textContent = "";
    }

    const funcSection = document.getElementById("functions-section");
    const fbody = document.getElementById("functions-table-body");
    fbody.innerHTML = "";
    if (data.functions && data.functions.length) {
      funcSection.classList.remove("hidden");
      data.functions.forEach((fn) => {
        const tr = document.createElement("tr");
        tr.innerHTML =
          "<td>" + fn.name + "</td>" +
          "<td class='num'>" + fn.lineno + "</td>" +
          "<td class='num'>" + fn.complexity + "</td>" +
          "<td class='num'><span class='func-rank'>" + fn.rank + "</span></td>";
        fbody.appendChild(tr);
      });
    } else {
      funcSection.classList.add("hidden");
    }
  }

  btnAnalyze.addEventListener("click", analyze);

  btnSample.addEventListener("click", async () => {
    const res = await fetch("/api/sample");
    const data = await res.json();
    codeInput.value = data.code;
  });
})();
