(function () {
  const DATA = window.DASHBOARD_DATA;
  const INK = "#16233B";
  const INK_SOFT = "#4A5670";
  const ACCENT = "#D98A2B";
  const GOOD = "#3E7C59";
  const BAD = "#AE3E2C";
  const GRID = "#DCE2D6";
  const MONO = "'IBM Plex Mono', monospace";

  Chart.defaults.font.family = MONO;
  Chart.defaults.color = INK_SOFT;
  Chart.defaults.borderColor = GRID;

  function labelOf(key) {
    return (DATA.labels && DATA.labels[key]) || key;
  }

  function topEntries(obj, n, byAbs) {
    let entries = Object.entries(obj);
    entries.sort((a, b) => (byAbs ? Math.abs(b[1]) - Math.abs(a[1]) : b[1] - a[1]));
    return entries.slice(0, n);
  }

  // --- Correlation with defects ---
  const corrEntries = topEntries(DATA.jm1.correlation_with_defects, 10, true);
  new Chart(document.getElementById("chart-correlation"), {
    type: "bar",
    data: {
      labels: corrEntries.map(([k]) => labelOf(k)),
      datasets: [{
        label: "Correlation with defects",
        data: corrEntries.map(([, v]) => v),
        backgroundColor: corrEntries.map(([, v]) => (v >= 0 ? ACCENT : GOOD)),
      }],
    },
    options: {
      indexAxis: "y",
      plugins: { legend: { display: false }, title: { display: true, text: "Top correlations", color: INK, font: { family: MONO, size: 12 } } },
      scales: { x: { grid: { color: GRID } }, y: { grid: { display: false } } },
    },
  });

  // --- Feature importance ---
  const impEntries = topEntries(DATA.jm1.feature_importance, 10, false);
  new Chart(document.getElementById("chart-importance"), {
    type: "bar",
    data: {
      labels: impEntries.map(([k]) => labelOf(k)),
      datasets: [{
        label: "Model importance",
        data: impEntries.map(([, v]) => v),
        backgroundColor: INK,
      }],
    },
    options: {
      indexAxis: "y",
      plugins: { legend: { display: false }, title: { display: true, text: "Top model feature importance", color: INK, font: { family: MONO, size: 12 } } },
      scales: { x: { grid: { color: GRID } }, y: { grid: { display: false } } },
    },
  });

  // --- Clean vs defective ---
  const compareKeys = ["loc", "v(g)", "d", "e", "branchCount"];
  new Chart(document.getElementById("chart-clean-vs-defect"), {
    type: "bar",
    data: {
      labels: compareKeys.map(labelOf),
      datasets: [
        { label: "Clean modules", data: compareKeys.map(k => DATA.jm1.mean_clean[k]), backgroundColor: GOOD },
        { label: "Defective modules", data: compareKeys.map(k => DATA.jm1.mean_defective[k]), backgroundColor: BAD },
      ],
    },
    options: {
      plugins: { legend: { position: "top", labels: { color: INK_SOFT } } },
      scales: { x: { grid: { display: false } }, y: { grid: { color: GRID } } },
    },
  });

  // --- Refactoring before/after ---
  const refKeys = ["cbo", "wmc", "lcom", "loc"];
  function refactorChart(canvasId, group) {
    new Chart(document.getElementById(canvasId), {
      type: "bar",
      data: {
        labels: refKeys.map(labelOf),
        datasets: [
          { label: "Before", data: refKeys.map(k => group.mean_before[k]), backgroundColor: "#9AA596" },
          { label: "After", data: refKeys.map(k => group.mean_after[k]), backgroundColor: ACCENT },
        ],
      },
      options: {
        plugins: { legend: { position: "top", labels: { color: INK_SOFT } } },
        scales: { x: { grid: { display: false } }, y: { grid: { color: GRID } } },
      },
    });
  }
  refactorChart("chart-refactor-nontrivial", DATA.refactor.nontrivial);
  refactorChart("chart-refactor-trivial", DATA.refactor.trivial);
})();
