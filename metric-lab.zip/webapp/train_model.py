import pandas as pd
import numpy as np
import json
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, roc_auc_score
import pickle

df = pd.read_csv('jm1.csv')
df['defects'] = df['defects'].astype(bool).astype(int)

feature_cols = ['loc','v(g)','ev(g)','iv(g)','n','v','l','d','i','e','b','t',
                 'lOCode','lOComment','lOBlank','locCodeAndComment',
                 'uniq_Op','uniq_Opnd','total_Op','total_Opnd','branchCount']

X = df[feature_cols]
y = df['defects']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s = scaler.transform(X_test)

clf = RandomForestClassifier(n_estimators=300, max_depth=12, class_weight='balanced', random_state=42, n_jobs=-1)
clf.fit(X_train_s, y_train)

y_pred = clf.predict(X_test_s)
y_proba = clf.predict_proba(X_test_s)[:,1]
report = classification_report(y_test, y_pred, output_dict=True)
auc = roc_auc_score(y_test, y_proba)
print(json.dumps(report, indent=2))
print('AUC:', auc)

with open('model.pkl','wb') as f:
    pickle.dump(clf, f)
with open('scaler.pkl','wb') as f:
    pickle.dump(scaler, f)

# feature importance
importances = dict(zip(feature_cols, clf.feature_importances_.tolist()))
importances = dict(sorted(importances.items(), key=lambda x: -x[1]))

# correlation with defects
corr = df[feature_cols + ['defects']].corr()['defects'].drop('defects').to_dict()

# class-wise means for comparison (defective vs clean)
means_defect = df[df['defects']==1][feature_cols].mean().to_dict()
means_clean = df[df['defects']==0][feature_cols].mean().to_dict()

stats = {
    'feature_importance': importances,
    'correlation_with_defects': corr,
    'mean_defective': means_defect,
    'mean_clean': means_clean,
    'defect_rate': float(df['defects'].mean()),
    'total_modules': int(len(df)),
    'model_metrics': {
        'accuracy': report['accuracy'],
        'precision_defect': report['1']['precision'],
        'recall_defect': report['1']['recall'],
        'f1_defect': report['1']['f1-score'],
        'auc': auc
    },
    'feature_cols': feature_cols
}

with open('jm1_stats.json','w') as f:
    json.dump(stats, f, indent=2)

print("Saved model.pkl, scaler.pkl, jm1_stats.json")
