# Metric Lab — Software Metrics vs Code Maintainability

A Flask web app for a software engineering coursework project on the
relationship between software metrics and code maintainability.

## What it does

- **Dashboard** (`/`) — insights precomputed from two datasets:
  - `jm1.csv` (NASA JM1): McCabe + Halstead metrics vs reported defects.
    Includes a trained Random Forest defect-prediction model, feature
    correlation with defects, feature importance, and clean-vs-defective
    metric comparisons.
  - The refactoring corpus (`OnlyTrivial_dt.csv` / `OnlyNonTrivial_dt.csv`):
    class-level CK metrics captured before/after real refactoring commits,
    compared for trivial vs non-trivial refactorings.
- **Analyze Code** (`/analyze`) — paste Python code, get:
  - Standard Maintainability Index (via `radon`)
  - A JM1-style metric vector (cyclomatic complexity, Halstead metrics, size counts)
  - Defect-risk probability from the trained model
  - Per-function complexity breakdown

## Run it

```bash
pip install -r requirements.txt
python3 app.py
```

Then open http://localhost:5000

## Project structure

```
app.py                 Flask routes
metrics_engine.py       Code -> metrics -> prediction pipeline (uses radon + the trained model)
model/
  model.pkl              Trained RandomForestClassifier (defect prediction)
  scaler.pkl             StandardScaler used before prediction
  jm1_stats.json         Precomputed JM1 insights (correlations, importances, class means)
  refactoring_stats.json Precomputed before/after refactoring metric averages
templates/               Jinja2 HTML templates
static/css, static/js    Styling and chart rendering (Chart.js via CDN)
```

## Notes on accuracy (worth mentioning in your report)

- `ev(g)` (essential complexity), `iv(g)` (design complexity), and
  `locCodeAndComment` cannot be derived from `radon` without full
  control-flow-graph analysis, so they're approximated (documented in
  `metrics_engine.APPROXIMATED_FEATURES` and flagged in the UI whenever
  you analyze code).
- The analyzer only supports Python. JM1's original metrics were computed
  on C modules; the refactoring dataset's CK metrics are Java-specific.
  Halstead metrics and cyclomatic complexity generalize across languages
  reasonably well, which is why they're the basis for the live analyzer.
- The JM1 model's recall on the defective class (~42%) is typical for this
  dataset in published literature — it's a hard, imbalanced problem, and
  that's a legitimate point to discuss in your analysis rather than a bug.

## Regenerating the model / stats

Both prep scripts read from the original CSVs (not included in this
folder to keep it small) and write into `model/`:

- `train_model.py` — trains the classifier on `jm1.csv`, writes `model.pkl`,
  `scaler.pkl`, `jm1_stats.json`.
- `analyze_refactoring.py` — aggregates `OnlyTrivial_dt.csv` /
  `OnlyNonTrivial_dt.csv` into `refactoring_stats.json`.
