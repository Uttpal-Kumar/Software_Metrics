import pandas as pd
import json

metric_cols = ['cbo','wmc','dit','noc','rfc','lcom','lcom*','tcc','lcc','loc',
               'totalMethodsQty','maxNestedBlocksQty','returnQty','loopQty']

def process(path, label):
    usecols = ['refactoring','type'] + metric_cols
    chunks = []
    for chunk in pd.read_csv(path, usecols=usecols, chunksize=100000):
        chunks.append(chunk)
    df = pd.concat(chunks, ignore_index=True)
    means = df.groupby('refactoring')[metric_cols].mean()
    counts = df['refactoring'].value_counts().to_dict()
    result = {
        'label': label,
        'n_before': int(counts.get(0,0)),
        'n_after': int(counts.get(1,0)),
        'mean_before': means.loc[0].to_dict() if 0 in means.index else {},
        'mean_after': means.loc[1].to_dict() if 1 in means.index else {}
    }
    return result

nontrivial = process('NonTrivial/OnlyNonTrivial_dt.csv', 'Non-Trivial Refactoring')
trivial = process('Trivial/OnlyTrivial_dt.csv', 'Trivial Refactoring')

with open('refactoring_stats.json','w') as f:
    json.dump({'nontrivial': nontrivial, 'trivial': trivial, 'metric_cols': metric_cols}, f, indent=2)

print(json.dumps(nontrivial, indent=2))
print(json.dumps(trivial, indent=2))
