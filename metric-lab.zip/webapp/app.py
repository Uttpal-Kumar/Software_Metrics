import json
from pathlib import Path

from flask import Flask, render_template, request, jsonify

from metrics_engine import analyze_code, CodeAnalysisError, FEATURE_LABELS

BASE_DIR = Path(__file__).parent

with open(BASE_DIR / "model" / "jm1_stats.json") as f:
    JM1_STATS = json.load(f)
with open(BASE_DIR / "model" / "refactoring_stats.json") as f:
    REFACTOR_STATS = json.load(f)

app = Flask(__name__)


@app.route("/")
def index():
    return render_template(
        "index.html",
        jm1_stats=JM1_STATS,
        refactor_stats=REFACTOR_STATS,
        feature_labels=FEATURE_LABELS,
    )


@app.route("/analyze")
def analyze_page():
    return render_template(
        "analyze.html",
        jm1_stats=JM1_STATS,
        feature_labels=FEATURE_LABELS,
    )


@app.route("/api/analyze", methods=["POST"])
def api_analyze():
    payload = request.get_json(silent=True) or {}
    code = payload.get("code", "")
    try:
        result = analyze_code(code)
    except CodeAnalysisError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify(result)


@app.route("/api/sample")
def api_sample():
    sample = '''class InventoryManager:
    def __init__(self, items=None):
        self.items = items or {}

    def add_item(self, name, qty, price):
        if qty < 0 or price < 0:
            raise ValueError("qty and price must be non-negative")
        if name in self.items:
            self.items[name]["qty"] += qty
        else:
            self.items[name] = {"qty": qty, "price": price}

    def remove_item(self, name, qty):
        if name not in self.items:
            return False
        if self.items[name]["qty"] < qty:
            return False
        self.items[name]["qty"] -= qty
        if self.items[name]["qty"] == 0:
            del self.items[name]
        return True

    def total_value(self):
        total = 0
        for name, info in self.items.items():
            if info["qty"] > 0:
                for _ in range(info["qty"]):
                    total += info["price"]
        return total

    def apply_discount(self, name, pct):
        if name in self.items:
            if pct > 0 and pct <= 100:
                self.items[name]["price"] *= (1 - pct / 100)
            else:
                raise ValueError("invalid discount")
'''
    return jsonify({"code": sample})


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
