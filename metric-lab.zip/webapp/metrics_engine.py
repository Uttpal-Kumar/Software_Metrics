"""
Computes software metrics from pasted Python source code using radon,
maps them onto the JM1-style feature set, runs the trained defect-risk
model, and returns a single dashboard-ready payload.

Two metrics (ev(g) essential complexity and iv(g) design complexity) can't
be derived from radon without full control-flow-graph analysis, so they are
approximated (documented in APPROXIMATED_FEATURES) rather than silently
faked.
"""
import ast
import pickle
from pathlib import Path

import pandas as pd

from radon.raw import analyze as raw_analyze
from radon.complexity import cc_visit, cc_rank
from radon.metrics import h_visit, mi_visit

MODEL_DIR = Path(__file__).parent / "model"

with open(MODEL_DIR / "model.pkl", "rb") as f:
    MODEL = pickle.load(f)
with open(MODEL_DIR / "scaler.pkl", "rb") as f:
    SCALER = pickle.load(f)

FEATURE_COLS = ['loc', 'v(g)', 'ev(g)', 'iv(g)', 'n', 'v', 'l', 'd', 'i', 'e', 'b', 't',
                'lOCode', 'lOComment', 'lOBlank', 'locCodeAndComment',
                'uniq_Op', 'uniq_Opnd', 'total_Op', 'total_Opnd', 'branchCount']

APPROXIMATED_FEATURES = {"ev(g)", "iv(g)", "locCodeAndComment"}

FEATURE_LABELS = {
    'loc': 'Lines of Code', 'v(g)': 'Cyclomatic Complexity', 'ev(g)': 'Essential Complexity',
    'iv(g)': 'Design Complexity', 'n': 'Halstead Vocabulary', 'v': 'Halstead Volume',
    'l': 'Halstead Level', 'd': 'Halstead Difficulty', 'i': 'Halstead Intelligence',
    'e': 'Halstead Effort', 'b': 'Estimated Bugs', 't': 'Time to Implement (s)',
    'lOCode': 'Lines of Code (exec.)', 'lOComment': 'Comment Lines', 'lOBlank': 'Blank Lines',
    'locCodeAndComment': 'Mixed Code/Comment Lines', 'uniq_Op': 'Unique Operators',
    'uniq_Opnd': 'Unique Operands', 'total_Op': 'Total Operators', 'total_Opnd': 'Total Operands',
    'branchCount': 'Branch Count',
}


class CodeAnalysisError(Exception):
    pass


def _safe_div(a, b):
    return a / b if b else 0.0


def analyze_code(source: str) -> dict:
    if not source or not source.strip():
        raise CodeAnalysisError("Paste some Python code first.")

    try:
        ast.parse(source)
    except SyntaxError as e:
        raise CodeAnalysisError(f"Syntax error on line {e.lineno}: {e.msg}")

    raw = raw_analyze(source)
    functions = cc_visit(source)

    if functions:
        complexities = [fn.complexity for fn in functions]
        avg_complexity = sum(complexities) / len(complexities)
        branch_count = sum(complexities)
    else:
        avg_complexity = 1.0
        branch_count = 1.0

    try:
        h = h_visit(source).total
    except Exception:
        h = None

    if h and h.vocabulary:
        n_ = h.vocabulary
        v_ = h.volume
        d_ = h.difficulty
        e_ = h.effort
        b_ = h.bugs
        t_ = h.time
        l_ = _safe_div(1.0, d_)
        i_ = _safe_div(v_, d_)
        uniq_op, uniq_opnd = h.h1, h.h2
        total_op, total_opnd = h.N1, h.N2
    else:
        n_ = v_ = d_ = e_ = b_ = t_ = l_ = i_ = 0.0
        uniq_op = uniq_opnd = total_op = total_opnd = 0

    try:
        mi = mi_visit(source, True)
    except Exception:
        mi = 0.0

    features = {
        'loc': float(raw.loc),
        'v(g)': float(avg_complexity),
        'ev(g)': 1.0,                       # approximated
        'iv(g)': float(avg_complexity),     # approximated
        'n': float(n_), 'v': float(v_), 'l': float(l_), 'd': float(d_),
        'i': float(i_), 'e': float(e_), 'b': float(b_), 't': float(t_),
        'lOCode': float(raw.sloc),
        'lOComment': float(raw.comments + raw.multi),
        'lOBlank': float(raw.blank),
        'locCodeAndComment': 0.0,           # approximated
        'uniq_Op': float(uniq_op), 'uniq_Opnd': float(uniq_opnd),
        'total_Op': float(total_op), 'total_Opnd': float(total_opnd),
        'branchCount': float(branch_count),
    }

    X = pd.DataFrame([[features[c] for c in FEATURE_COLS]], columns=FEATURE_COLS)
    X_scaled = SCALER.transform(X)
    proba = float(MODEL.predict_proba(X_scaled)[0][1])

    if mi >= 85:
        mi_label, mi_band = "Highly maintainable", "good"
    elif mi >= 65:
        mi_label, mi_band = "Moderately maintainable", "warn"
    else:
        mi_label, mi_band = "Hard to maintain", "bad"

    if proba < 0.3:
        risk_label, risk_band = "Low defect risk", "good"
    elif proba < 0.6:
        risk_label, risk_band = "Moderate defect risk", "warn"
    else:
        risk_label, risk_band = "High defect risk", "bad"

    function_table = [
        {
            "name": fn.name,
            "lineno": fn.lineno,
            "complexity": fn.complexity,
            "rank": cc_rank(fn.complexity),
        }
        for fn in functions
    ]

    return {
        "features": features,
        "feature_labels": FEATURE_LABELS,
        "approximated": sorted(APPROXIMATED_FEATURES),
        "maintainability_index": round(mi, 1),
        "maintainability_label": mi_label,
        "maintainability_band": mi_band,
        "defect_probability": round(proba, 4),
        "risk_label": risk_label,
        "risk_band": risk_band,
        "functions": function_table,
    }
